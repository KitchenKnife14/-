# Общий бюджет

Совместный учёт доходов, расходов и накоплений для двух человек с планированием будущих трат и отчётами.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Web: React + Vite, Wouter, TanStack Query
- Authentication: Replit-managed Clerk

## Where things live

- `artifacts/budget-for-two/` — Russian-language web app, household setup, finance screens, and Clerk auth.
- `artifacts/api-server/src/routes/household.ts` — household creation, joining, and membership.
- `artifacts/api-server/src/routes/finance.ts` — transactions, goals, dashboard, and reports.
- `lib/db/src/schema/budget.ts` — PostgreSQL schema for household finance records.
- `lib/api-spec/openapi.yaml` — API source of truth for generated hooks and validators.

## Architecture decisions

- Clerk authenticates each person; household membership is stored in PostgreSQL and finance queries are scoped to that household.
- A household is limited to two members. The first person creates it and shares an invite code with the second.
- Planned and recorded entries share one ledger. Savings contributions link to a goal; goal progress is derived from recorded contributions.
- Payments currently mean recording payment activity, not initiating bank transfers. Telegram integration was deferred for a later step.

## Product

- Track shared income, expenses, and savings contributions.
- Plan future expenses and mark entries as recorded or planned.
- Create savings goals and view monthly or custom-period reports.
- Invite a second person into the same household budget.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
