import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/shared/keys';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import {
  ArrowDownLeft, ArrowLeftRight, ArrowRight, ArrowUpRight, CalendarDays, Check,
  CircleHelp, CreditCard, FileText, Heart, Home, LogOut, Plus, RefreshCw,
  Settings2, ShieldCheck, Sparkles, Target, Trash2, TrendingUp, Wallet, X,
} from 'lucide-react';
import {
  getGetDashboardQueryKey, getGetHouseholdQueryKey, getGetReportQueryKey, getListGoalsQueryKey,
  getListTransactionsQueryKey, useCreateGoal, useCreateHousehold, useCreateTransaction,
  useDeleteGoal, useDeleteTransaction, useGetDashboard, useGetHousehold, useGetReport,
  useHealthCheck, useJoinHousehold, useListGoals, useListTransactions, useUpdateGoal,
  useUpdateTransaction,
} from '@workspace/api-client-react';
import type { Goal, GoalInput, GoalUpdate, Transaction, TransactionInput, TransactionUpdate } from '@workspace/api-client-react';
import './index.css';

const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 15_000, refetchOnWindowFocus: true } } });
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
function stripBase(path: string) { return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path; }

const money = (n: number) => new Intl.NumberFormat('ru-RU', { style: 'currency', currency: 'RUB', maximumFractionDigits: 0 }).format(n || 0);
const dateRu = (value?: string | null) => value ? new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' }).format(new Date(value + (value.length === 10 ? 'T12:00:00' : ''))) : 'Без срока';
const monthRu = (value?: string) => value ? new Intl.DateTimeFormat('ru-RU', { month: 'long', year: 'numeric' }).format(new Date(`${value}-01T12:00:00`)) : '';
const today = () => new Date().toISOString().slice(0, 10);
const currentMonthStart = () => `${today().slice(0, 7)}-01`;
const iconForType = (type: string) => type === 'income' ? ArrowDownLeft : type === 'saving' ? Target : ArrowUpRight;
const typeName = (type: string) => type === 'income' ? 'Доход' : type === 'saving' ? 'В накопления' : 'Расход';
const categoryHue = ['sage', 'peach', 'blue', 'sand', 'rose'];

function useRefresh() {
  const qc = useQueryClient();
  return () => Promise.all([
    qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }),
    qc.invalidateQueries({ queryKey: getListTransactionsQueryKey() }),
    qc.invalidateQueries({ queryKey: getListGoalsQueryKey() }),
    qc.invalidateQueries({ queryKey: getGetReportQueryKey() }),
    qc.invalidateQueries({ queryKey: getGetHouseholdQueryKey() }),
  ]);
}

function Brand({ compact = false }: { compact?: boolean }) {
  return <div className="brand-mark">
    <span className="brand-icon"><img src={`${basePath}/logo.svg`} alt="" /></span>
    {!compact && <span className="brand-word">вдвоём<span>финансы дома</span></span>}
  </div>;
}

function Landing() {
  return <main className="landing">
    <header className="landing-nav"><Brand /><div className="landing-links"><a href="#how">Как это работает</a><Link href="/sign-in" className="landing-login">Войти <ArrowRight size={15} /></Link></div></header>
    <section className="landing-hero">
      <div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-dot" /> Личное пространство для двоих</div>
        <h1>Деньги дома.<br /><em>Спокойно, вместе.</em></h1>
        <p>Понятный общий бюджет без лишнего шума. Записывайте траты, планируйте важное и замечайте, как ваши общие цели становятся ближе.</p>
        <div className="hero-actions"><Link href="/sign-up" className="button button-primary">Начать вместе <ArrowRight size={16} /></Link><span>Бесплатно и только для вас двоих</span></div>
        <div className="hero-trust"><ShieldCheck size={16} /><span>Ваши цифры видны только вам и вашему близкому</span></div>
      </div>
      <div className="hero-art" aria-label="Иллюстрация домашнего бюджета">
        <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
        <div className="art-stamp">НАШ<br />БАЛАНС</div>
        <div className="ledger-card">
          <div className="ledger-top"><span>Ваше пространство · вместе</span><span className="ledger-avatars"><i /><i /></span></div>
          <small>ФИНАНСЫ В ОДНОМ МЕСТЕ</small><strong>Понятно <b>вам</b></strong>
          <div className="ledger-rule"><span /></div>
          <div className="ledger-row"><span>Доходы и расходы</span><b><ArrowRight size={14}/></b></div>
          <div className="ledger-row"><span>Будущие планы</span><b><ArrowRight size={14}/></b></div>
          <div className="ledger-note"><span className="note-icon"><Heart size={14} /></span><span>Общие цели и ваши шаги</span><b><Target size={14}/></b></div>
        </div>
        <div className="art-note note-top"><Sparkles size={14} /> Планы тоже учтены</div>
        <div className="art-note note-bottom"><span className="note-marker" /> Общее — значит наше</div>
        <div className="art-plant"><span /><span /><span /><span /><i /></div>
      </div>
    </section>
    <section className="landing-value" id="how">
      <div className="value-intro"><div className="eyebrow">Небольшая привычка, большая ясность</div><h2>Один бюджет.<br /><em>Два взгляда.</em></h2><p>Никаких таблиц, сложных правил и финансовых лекций. Только простые вещи, которые помогают быть на одной стороне.</p></div>
      <article className="value-item"><span className="value-number">01</span><Wallet size={21} /><h3>Видно, куда уходит</h3><p>Доходы и траты собраны в одном месте — история обновляется для вас обоих.</p></article>
      <article className="value-item"><span className="value-number">02</span><CalendarDays size={21} /><h3>Можно подготовиться</h3><p>Запланируйте крупную покупку или регулярный платёж заранее.</p></article>
      <article className="value-item"><span className="value-number">03</span><Target size={21} /><h3>Есть ради чего</h3><p>Создавайте общие цели и отмечайте каждый шаг к ним.</p></article>
    </section>
    <section className="landing-bottom"><span className="bottom-flourish">«</span><p>Хороший бюджет — не про ограничения.<br />Он про то, что вы выбираете вместе.</p><Link href="/sign-up" className="button button-primary">Создать пространство <ArrowRight size={16} /></Link></section>
    <footer className="landing-footer"><Brand compact /><span>Небольшой инструмент для большой команды из двух человек.</span><span>Только ваше. Всегда вместе.</span></footer>
  </main>;
}

function AuthHome() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div className="auth-loading"><Brand /><Loading label="Загружаем пространство" /></div>;
  return isSignedIn ? <Redirect to="/dashboard" /> : <Landing />;
}
function SignInPage() {
  return <div className="auth-page"><div className="auth-decoration"><Brand /><div><span className="eyebrow">Наши финансы, наше решение</span><h1>Пусть деньги<br /><em>работают на вас.</em></h1><p>Войдите, чтобы продолжить вести общий бюджет.</p></div><small>Приватное пространство для двух</small></div><div className="auth-card"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div></div>;
}
function SignUpPage() {
  return <div className="auth-page"><div className="auth-decoration"><Brand /><div><span className="eyebrow">Начинается с простого</span><h1>Ваш общий<br /><em>домашний ledger.</em></h1><p>Создайте аккаунт, а затем пригласите близкого человека.</p></div><small>Уже есть аккаунт? <Link href="/sign-in">Войти</Link></small></div><div className="auth-card"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div></div>;
}

function ClerkCacheInvalidator() {
  const { addListener } = useClerk(); const qc = useQueryClient(); const prev = useRef<string | null | undefined>(undefined);
  useEffect(() => { const unsub = addListener(({ user }) => { const id = user?.id ?? null; if (prev.current !== undefined && prev.current !== id) qc.clear(); prev.current = id; }); return unsub; }, [addListener, qc]);
  return null;
}

const navItems = [
  { href: '/dashboard', label: 'Обзор', icon: Home },
  { href: '/transactions', label: 'Операции', icon: ArrowLeftRight },
  { href: '/savings', label: 'Цели', icon: Target },
  { href: '/reports', label: 'Отчёты', icon: FileText },
];
function Sidebar({ path }: { path: string }) {
  const { signOut } = useClerk(); const { user } = useUser(); const health = useHealthCheck({ query: { refetchInterval: 60_000 } });
  const short = user?.firstName || user?.username || 'Вы';
  return <>
    <aside className="sidebar">
      <Link href="/dashboard" className="sidebar-brand"><Brand /></Link>
      <div className="space-label">НАШ ДОМ</div>
      <nav className="side-nav">{navItems.map(item => <Link key={item.href} href={item.href} className={`nav-link ${path === item.href ? 'active' : ''}`}><item.icon size={18} strokeWidth={1.8} />{item.label}</Link>)}</nav>
      <div className="sidebar-bottom">
        <div className="connection"><span className={`connection-dot ${health.isError ? 'offline' : ''}`} /><span>{health.isError ? 'Нет соединения' : 'Данные обновлены'}</span><button type="button" onClick={() => health.refetch()} aria-label="Обновить соединение" data-testid="button-refresh-connection"><RefreshCw size={13} /></button></div>
        <div className="profile-row"><span className="profile-avatar">{short.slice(0,1).toLocaleUpperCase('ru-RU')}</span><span className="profile-name">{short}<small>Участник бюджета</small></span><button className="icon-button" onClick={() => signOut({ redirectUrl: basePath || '/' })} aria-label="Выйти" data-testid="button-sign-out"><LogOut size={16} /></button></div>
      </div>
    </aside>
    <nav className="mobile-nav">{navItems.map(item => <Link key={item.href} href={item.href} className={`nav-link ${path === item.href ? 'active' : ''}`}><item.icon size={19} />{item.label}</Link>)}</nav>
  </>;
}

function AppFrame({ children, title, subtitle, action }: { children: ReactNode; title: string; subtitle?: string; action?: ReactNode }) {
  const [path] = useLocation();
  return <div className="app-shell"><Sidebar path={path} /><main className="main-area"><div className="content-wrap">
    <div className="page-heading"><div><div className="page-kicker">ОБЩИЙ БЮДЖЕТ</div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{action && <div className="heading-action">{action}</div>}</div>{children}
  </div></main></div>;
}

function Loading({ label = 'Загружаем ваши данные' }: { label?: string }) { return <div className="loading-panel"><div className="skeleton-line" /><div className="skeleton-line short" /><span>{label}</span></div>; }
function ErrorState({ retry, label = 'Не получилось загрузить данные' }: { retry: () => void; label?: string }) { return <div className="empty-state"><span className="empty-icon"><CircleHelp size={22} /></span><h3>{label}</h3><p>Проверьте соединение и попробуйте ещё раз.</p><button className="button button-soft" onClick={retry} data-testid="button-retry"><RefreshCw size={15} /> Повторить</button></div>; }
function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) { return <div className="empty-state"><span className="empty-icon"><Heart size={20} /></span><h3>{title}</h3><p>{body}</p>{action}</div>; }
function StatCard({ label, value, icon: Icon, tone = '' }: { label: string; value: number; icon: typeof Wallet; tone?: string }) {
  return <article className={`stat-card ${tone}`}><div className="stat-label"><span>{label}</span><Icon size={16} /></div><strong>{money(value)}</strong></article>;
}

function TransactionRow({ item, onEdit, onDelete }: { item: Transaction; onEdit: (t: Transaction) => void; onDelete: (t: Transaction) => void }) {
  const Icon = iconForType(item.type);
  return <div className="transaction-row" data-testid={`row-transaction-${item.id}`}>
    <span className={`transaction-symbol ${item.type}`}><Icon size={17} /></span>
    <div className="transaction-main"><strong>{item.description}</strong><span>{item.category}{item.goalName ? ` · ${item.goalName}` : ''} <i>·</i> {dateRu(item.transactionDate)}{item.status === 'planned' ? <em className="planned-pill">План</em> : ''}</span></div>
    <span className={`transaction-amount ${item.type}`}>{item.type === 'expense' ? '−' : '+'}{money(item.amount)}</span>
    <div className="row-actions"><button className="icon-button" onClick={() => onEdit(item)} aria-label="Изменить" data-testid={`button-edit-transaction-${item.id}`}><Settings2 size={15} /></button><button className="icon-button danger-icon" onClick={() => onDelete(item)} aria-label="Удалить" data-testid={`button-delete-transaction-${item.id}`}><Trash2 size={15} /></button></div>
  </div>;
}

function Modal({ title, description, onClose, children }: { title: string; description?: string; onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className="modal-card" role="dialog" aria-modal="true" aria-label={title}>
    <div className="modal-head"><div><h2>{title}</h2>{description && <p>{description}</p>}</div><button className="icon-button" onClick={onClose} aria-label="Закрыть" data-testid="button-close-modal"><X size={18} /></button></div>{children}
  </section></div>;
}

function TransactionForm({ initial, goals, onSubmit, busy, onClose, presetGoal, error }: { initial?: Transaction; goals: Goal[]; onSubmit: (data: TransactionInput | TransactionUpdate) => void; busy: boolean; onClose: () => void; presetGoal?: Goal; error?: string }) {
  const [type, setType] = useState<Transaction['type']>(initial?.type ?? (presetGoal ? 'saving' : 'expense'));
  const [amount, setAmount] = useState(initial ? String(initial.amount) : '');
  const [category, setCategory] = useState(initial?.category ?? (presetGoal ? 'Сбережения' : 'Продукты'));
  const [description, setDescription] = useState(initial?.description ?? (presetGoal ? `В цель «${presetGoal.name}»` : ''));
  const [transactionDate, setTransactionDate] = useState(initial?.transactionDate ?? today());
  const [status, setStatus] = useState<Transaction['status']>(initial?.status ?? 'recorded');
  const [goalId, setGoalId] = useState<string>(String(initial?.goalId ?? presetGoal?.id ?? ''));
  const submit = (e: FormEvent) => { e.preventDefault(); const data = { type, amount: Number(amount), category: category.trim(), description: description.trim(), transactionDate, status, goalId: type === 'saving' && goalId ? Number(goalId) : null }; onSubmit(data); };
  return <form className="form-stack" onSubmit={submit}>
    <div><label className="field-label">Тип операции</label><div className="segmented">{(['expense','income','saving'] as const).map(value => <button type="button" key={value} className={type === value ? 'selected' : ''} onClick={() => setType(value)} data-testid={`select-type-${value}`}>{typeName(value)}</button>)}</div></div>
    <div className="form-grid"><label><span className="field-label">Сумма, ₽</span><input className="field" type="number" min="1" step="1" required value={amount} onChange={e => setAmount(e.target.value)} placeholder="0" data-testid="input-amount" /></label><label><span className="field-label">Дата</span><input className="field" type="date" required value={transactionDate} onChange={e => setTransactionDate(e.target.value)} data-testid="input-transaction-date" /></label></div>
    <div className="form-grid"><label><span className="field-label">Категория</span><input className="field" maxLength={60} required value={category} onChange={e => setCategory(e.target.value)} placeholder="Например, дом" data-testid="input-category" /></label><label><span className="field-label">Описание</span><input className="field" maxLength={200} required value={description} onChange={e => setDescription(e.target.value)} placeholder="На что потратили или откуда доход" data-testid="input-description" /></label></div>
    {type === 'saving' && <label><span className="field-label">Цель накопления</span><select className="field" value={goalId} onChange={e => setGoalId(e.target.value)} data-testid="select-goal"><option value="">Без привязки к цели</option>{goals.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}</select></label>}
    <div className="status-choice"><label className="field-label">Состояние</label><label><input type="radio" checked={status === 'recorded'} onChange={() => setStatus('recorded')} /> Уже произошло</label><label><input type="radio" checked={status === 'planned'} onChange={() => setStatus('planned')} /> Запланировано</label></div>
    {error&&<p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-soft" onClick={onClose}>Отмена</button><button className="button button-primary" disabled={busy || !amount || !description.trim()} type="submit">{busy ? 'Сохраняем…' : initial ? 'Сохранить' : 'Добавить операцию'}</button></div>
  </form>;
}

function Dashboard() {
  const q = useGetDashboard({ query: { refetchInterval: 30_000 } }); const hq = useGetHousehold(); const [transaction, setTransaction] = useState<Transaction | undefined>(); const [formOpen, setFormOpen] = useState(false); const [copied,setCopied]=useState(false);
  const [deleteItem, setDeleteItem] = useState<Transaction | null>(null); const refresh = useRefresh(); const goalsQ = useListGoals();
  const create = useCreateTransaction(); const update = useUpdateTransaction(); const remove = useDeleteTransaction();
  const submit = (data: TransactionInput | TransactionUpdate) => {
    const done = () => { void refresh(); setFormOpen(false); setTransaction(undefined); };
    if (transaction) update.mutate({ id: transaction.id, data: data as TransactionUpdate }, { onSuccess: done });
    else create.mutate({ data: data as TransactionInput }, { onSuccess: done });
  };
  const close = () => { setFormOpen(false); setTransaction(undefined); };
  const memberNames = hq.data?.members?.map(m => m.displayName).filter(Boolean) ?? [];
  if (q.isLoading) return <AppFrame title="Обзор" subtitle="Ваш общий бюджет"><Loading /></AppFrame>;
  if (q.isError || !q.data) return <AppFrame title="Обзор"><ErrorState retry={() => q.refetch()} /></AppFrame>;
  const d = q.data; const categories = [...d.expenseByCategory].sort((a,b) => b.amount-a.amount).slice(0,4); const max = Math.max(1,...categories.map(c=>c.amount));
  return <AppFrame title="Обзор" subtitle={`${monthRu(d.month)} · ${memberNames.length === 2 ? `${memberNames[0]} и ${memberNames[1]}` : 'ваш общий бюджет'}`} action={<button className="button button-primary" onClick={() => setFormOpen(true)} data-testid="button-add-transaction"><Plus size={17} /> Добавить операцию</button>}>
    <section className="overview-hero panel">
      <div className="overview-copy"><span>ДОСТУПНО В ЭТОМ МЕСЯЦЕ</span><strong>{money(d.available)}</strong><p>После учтённых расходов и накоплений</p></div>
      <div className="overview-decoration"><span className="decor-ring ring-a" /><span className="decor-ring ring-b" /><span className="decor-spark"><Heart size={18} /></span><small>Вместе<br />понятнее</small></div>
      <div className="overview-month"><CalendarDays size={15} /> {monthRu(d.month)}</div>
    </section>
    <div className="stats-grid">
      <StatCard label="Доходы" value={d.income} icon={ArrowDownLeft} tone="income-card" />
      <StatCard label="Расходы" value={d.expenses} icon={ArrowUpRight} tone="expense-card" />
      <StatCard label="В накопления" value={d.savings} icon={Target} tone="saving-card" />
      <StatCard label="Запланировано" value={d.plannedExpenses} icon={CalendarDays} tone="planned-card" />
    </div>
    <div className="dashboard-grid">
      <section className="panel section-panel"><div className="section-title"><div><span className="section-kicker">ЧТО ПРОИСХОДИТ</span><h2>Последние операции</h2></div><Link className="text-link" href="/transactions">Вся история <ArrowRight size={14} /></Link></div>
        {d.recentTransactions.length ? <div className="transactions-list">{d.recentTransactions.slice(0,5).map(t => <TransactionRow key={t.id} item={t} onEdit={item => { setTransaction(item); setFormOpen(true); }} onDelete={setDeleteItem} />)}</div> : <EmptyState title="Здесь появится ваша история" body="Добавьте первую операцию — так вы начнёте видеть общую картину." action={<button className="button button-primary" onClick={() => setFormOpen(true)}>Добавить первую</button>} />}
      </section>
      <div className="side-panels">
        <section className="panel section-panel category-panel"><div className="section-title"><div><span className="section-kicker">РАСХОДЫ</span><h2>По категориям</h2></div><CreditCard size={17} /></div>
          {categories.length ? <div className="category-list">{categories.map((c,i) => <div className="category-item" key={c.category}><div className="category-head"><span><i className={`category-dot ${categoryHue[i % categoryHue.length]}`} />{c.category}</span><b>{money(c.amount)}</b></div><div className="category-track"><span className={categoryHue[i % categoryHue.length]} style={{ width:`${Math.max(4,c.amount/max*100)}%` }} /></div></div>)}</div> : <p className="muted-note">Пока нет учтённых расходов.</p>}
          <Link href="/reports" className="category-footer">Открыть отчёт <ArrowRight size={14} /></Link>
        </section>
        <section className="planned-card-panel"><span className="planned-sun"><CalendarDays size={18} /></span><div><strong>Планы на месяц</strong><p>{d.plannedExpenses > 0 ? `Предусмотрено ${money(d.plannedExpenses)} будущих расходов` : 'Запишите предстоящий расход, чтобы учесть его заранее.'}</p></div><button onClick={() => setFormOpen(true)} aria-label="Добавить план" data-testid="button-add-plan"><Plus size={17} /></button></section>
        {goalsQ.data?.length ? <Link href="/savings" className="goal-teaser panel"><span className="goal-teaser-icon"><Target size={17} /></span><span><b>Общие цели</b><small>{goalsQ.data.length} {goalsQ.data.length === 1 ? 'цель' : 'целей'} в работе</small></span><ArrowRight size={16} /></Link> : null}
        {hq.data?.household && hq.data.members.length < 2 && <section className="invite-card panel"><div className="invite-heading"><span className="invite-icon"><Heart size={16}/></span><div><strong>Позовите близкого</strong><p>Поделитесь кодом — бюджет станет общим.</p></div></div><div className="invite-code"><span>{hq.data.household.inviteCode}</span><button className="button button-soft" onClick={() => { void navigator.clipboard?.writeText(hq.data!.household!.inviteCode).then(()=>{setCopied(true);window.setTimeout(()=>setCopied(false),1800)}); }} data-testid="button-copy-invite">{copied?<><Check size={14}/> Скопировано</>:<>Копировать</>}</button></div></section>}
      </div>
    </div>
    {formOpen && <Modal title={transaction ? 'Изменить операцию' : 'Новая операция'} description="Запись увидите вы оба." onClose={close}><TransactionForm initial={transaction} goals={goalsQ.data ?? []} onSubmit={submit} busy={create.isPending || update.isPending} onClose={close} error={create.isError||update.isError?'Не удалось сохранить запись. Проверьте данные и попробуйте снова.':undefined} /></Modal>}
    {deleteItem && <Modal title="Удалить операцию?" description="Эта запись исчезнет из общего бюджета." onClose={() => setDeleteItem(null)}>{remove.isError&&<p className="form-error">Не удалось удалить запись. Попробуйте ещё раз.</p>}<div className="confirm-actions"><button className="button button-soft" onClick={() => setDeleteItem(null)}>Оставить</button><button className="button button-danger" disabled={remove.isPending} onClick={() => remove.mutate({ id:deleteItem.id }, { onSuccess: () => { setDeleteItem(null); void refresh(); } })} data-testid="confirm-delete-transaction">{remove.isPending ? 'Удаляем…' : 'Удалить запись'}</button></div></Modal>}
  </AppFrame>;
}

function TransactionsPage() {
  const [filters,setFilters] = useState({ type:'', status:'', fromDate:'', toDate:'' }); const [open,setOpen] = useState(false); const [editing,setEditing] = useState<Transaction | undefined>(); const [deleteItem,setDeleteItem] = useState<Transaction | null>(null);
  const params = { ...(filters.type ? {type:filters.type as 'income'|'expense'|'saving'} : {}), ...(filters.status ? {status:filters.status as 'recorded'|'planned'} : {}), ...(filters.fromDate ? {fromDate:filters.fromDate} : {}), ...(filters.toDate ? {toDate:filters.toDate} : {}) };
  const q = useListTransactions(params, { query: { refetchInterval:30_000 } }); const goalsQ = useListGoals(); const create = useCreateTransaction(); const update = useUpdateTransaction(); const remove = useDeleteTransaction(); const refresh = useRefresh();
  const close = () => { setOpen(false); setEditing(undefined); };
  const save = (data: TransactionInput | TransactionUpdate) => {
    const done = () => { close(); void refresh(); };
    if(editing) update.mutate({id:editing.id,data:data as TransactionUpdate},{onSuccess:done}); else create.mutate({data:data as TransactionInput},{onSuccess:done});
  };
  return <AppFrame title="Операции" subtitle="Все общие доходы, расходы и планы" action={<button className="button button-primary" onClick={() => setOpen(true)} data-testid="button-create-transaction"><Plus size={17} /> Добавить</button>}>
    <div className="filters-panel panel"><div className="filter-heading"><span><Settings2 size={16} /> Фильтры</span><button className="text-button" onClick={() => setFilters({type:'',status:'',fromDate:'',toDate:''})}>Сбросить</button></div><div className="filters-grid">
      <label><span className="field-label">Тип</span><select className="field" value={filters.type} onChange={e=>setFilters({...filters,type:e.target.value})} data-testid="filter-type"><option value="">Все операции</option><option value="expense">Расходы</option><option value="income">Доходы</option><option value="saving">Накопления</option></select></label>
      <label><span className="field-label">Статус</span><select className="field" value={filters.status} onChange={e=>setFilters({...filters,status:e.target.value})} data-testid="filter-status"><option value="">Любой</option><option value="recorded">Учтённые</option><option value="planned">Планы</option></select></label>
      <label><span className="field-label">С</span><input className="field" type="date" value={filters.fromDate} onChange={e=>setFilters({...filters,fromDate:e.target.value})} data-testid="filter-from" /></label>
      <label><span className="field-label">По</span><input className="field" type="date" value={filters.toDate} onChange={e=>setFilters({...filters,toDate:e.target.value})} data-testid="filter-to" /></label>
    </div></div>
    {q.isLoading ? <Loading label="Собираем историю операций" /> : q.isError ? <ErrorState retry={() => q.refetch()} /> :
      q.data?.length ? <section className="panel transactions-history"><div className="history-heading"><div><span className="section-kicker">ОБЩАЯ ЛЕНТА</span><h2>{q.data.length} {q.data.length === 1 ? 'операция' : 'операций'}</h2></div><button className="icon-button" onClick={() => q.refetch()} aria-label="Обновить историю" data-testid="button-refresh-transactions"><RefreshCw size={15} /></button></div><div className="transactions-list">{q.data.map(item => <TransactionRow key={item.id} item={item} onEdit={t=>{setEditing(t);setOpen(true)}} onDelete={setDeleteItem} />)}</div></section> :
      <EmptyState title={Object.values(filters).some(Boolean) ? 'По этим фильтрам ничего нет' : 'История пока пуста'} body={Object.values(filters).some(Boolean) ? 'Измените условия поиска или сбросьте фильтры.' : 'Первая запись станет началом вашей общей финансовой истории.'} action={<button className="button button-primary" onClick={() => Object.values(filters).some(Boolean) ? setFilters({type:'',status:'',fromDate:'',toDate:''}) : setOpen(true)}>{Object.values(filters).some(Boolean) ? 'Сбросить фильтры' : 'Добавить операцию'}</button>} />}
    {open && <Modal title={editing?'Изменить операцию':'Новая операция'} description="Запись сразу появится у вас обоих." onClose={close}><TransactionForm initial={editing} goals={goalsQ.data??[]} onSubmit={save} busy={create.isPending||update.isPending} onClose={close} error={create.isError||update.isError?'Не удалось сохранить запись. Проверьте данные и попробуйте снова.':undefined} /></Modal>}
    {deleteItem && <Modal title="Удалить операцию?" description="Удаление нельзя отменить." onClose={()=>setDeleteItem(null)}>{remove.isError&&<p className="form-error">Не удалось удалить запись. Попробуйте ещё раз.</p>}<div className="confirm-actions"><button className="button button-soft" onClick={()=>setDeleteItem(null)}>Отмена</button><button className="button button-danger" disabled={remove.isPending} onClick={()=>remove.mutate({id:deleteItem.id},{onSuccess:()=>{setDeleteItem(null);void refresh()}})}>Удалить</button></div></Modal>}
  </AppFrame>;
}

function GoalForm({ initial, onSubmit, busy, onClose, error }: { initial?:Goal; onSubmit:(data:GoalInput|GoalUpdate)=>void; busy:boolean; onClose:()=>void; error?:string }) {
  const [name,setName]=useState(initial?.name??''); const [target,setTarget]=useState(initial?String(initial.targetAmount):''); const [deadline,setDeadline]=useState(initial?.deadline??'');
  const submit=(e:FormEvent)=>{e.preventDefault();onSubmit({name:name.trim(),targetAmount:Number(target),deadline:deadline||null})};
  return <form className="form-stack" onSubmit={submit}><label><span className="field-label">Название цели</span><input className="field" value={name} onChange={e=>setName(e.target.value)} maxLength={100} placeholder="Например, поездка к морю" required data-testid="input-goal-name" /></label>
    <label><span className="field-label">Сколько нужно, ₽</span><input className="field" type="number" min="1" step="1" value={target} onChange={e=>setTarget(e.target.value)} placeholder="0" required data-testid="input-goal-target" /></label>
    <label><span className="field-label">Желаемая дата <small className="optional-label">необязательно</small></span><input className="field" type="date" value={deadline??''} onChange={e=>setDeadline(e.target.value)} data-testid="input-goal-deadline" /></label>
    {error&&<p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="button button-soft" onClick={onClose}>Отмена</button><button className="button button-primary" type="submit" disabled={busy||!name.trim()||!target}>{busy?'Сохраняем…':initial?'Сохранить цель':'Создать цель'}</button></div>
  </form>;
}
function SavingsPage() {
  const q=useListGoals({query:{refetchInterval:30_000}}); const txq=useListTransactions(); const [open,setOpen]=useState(false); const [editing,setEditing]=useState<Goal|undefined>(); const [deleteGoal,setDeleteGoal]=useState<Goal|null>(null); const [contribute,setContribute]=useState<Goal|undefined>();
  const create=useCreateGoal();const update=useUpdateGoal();const remove=useDeleteGoal();const refresh=useRefresh();const txcreate=useCreateTransaction();
  const close=()=>{setOpen(false);setEditing(undefined)};
  const save=(data:GoalInput|GoalUpdate)=>{const done=()=>{close();void refresh()};if(editing)update.mutate({id:editing.id,data:data as GoalUpdate},{onSuccess:done});else create.mutate({data:data as GoalInput},{onSuccess:done})};
  return <AppFrame title="Наши цели" subtitle="Накопления, которые приближают к важному" action={<button className="button button-primary" onClick={()=>setOpen(true)} data-testid="button-create-goal"><Plus size={17} /> Новая цель</button>}>
    <section className="savings-intro"><div><span className="section-kicker">МАЛЕНЬКИЕ ШАГИ</span><h2>Большие планы<br /><em>становятся ближе.</em></h2><p>Добавляйте взносы, отмечайте прогресс и двигайтесь в своём темпе.</p></div><span className="savings-orbit"><Target size={29} /></span></section>
    {q.isLoading?<Loading label="Загружаем ваши цели" />:q.isError?<ErrorState retry={()=>q.refetch()} />:q.data?.length?<div className="goal-grid">{q.data.map((goal,index)=>{
      const percent=Math.min(100,Math.max(0,goal.progressPercent));return <article className={`goal-card panel goal-tone-${index%3}`} key={goal.id} data-testid={`card-goal-${goal.id}`}>
        <div className="goal-card-top"><span className="goal-mark"><Target size={17} /></span><div className="goal-actions"><button className="icon-button" onClick={()=>{setEditing(goal);setOpen(true)}} aria-label="Изменить цель" data-testid={`button-edit-goal-${goal.id}`}><Settings2 size={15}/></button><button className="icon-button danger-icon" onClick={()=>setDeleteGoal(goal)} aria-label="Удалить цель" data-testid={`button-delete-goal-${goal.id}`}><Trash2 size={15}/></button></div></div>
        <h3>{goal.name}</h3><p className="goal-deadline">{goal.deadline?`До ${dateRu(goal.deadline)}`:'Без срока'}</p>
        <div className="goal-amounts"><strong>{money(goal.currentAmount)}</strong><span>из {money(goal.targetAmount)}</span></div>
        <div className="goal-progress"><span style={{width:`${percent}%`}} /></div><div className="goal-progress-foot"><span>{Math.round(percent)}% собрано</span><span>Осталось {money(Math.max(0,goal.targetAmount-goal.currentAmount))}</span></div>
        <button className="button button-soft contribution-button" onClick={()=>setContribute(goal)} data-testid={`button-contribute-${goal.id}`}><Plus size={15}/> Добавить взнос</button>
      </article>})}</div>:<EmptyState title="Пока нет общей цели" body="Мечта может быть любой: отпуск, первый взнос или уютный дом. Давайте начнём с одной." action={<button className="button button-primary" onClick={()=>setOpen(true)}><Plus size={16}/> Создать первую цель</button>} />}
    {txq.data?.some(t=>t.type==='saving') && <div className="savings-footnote"><span><Check size={15}/></span> Взносы отображаются в истории операций и обновляются для вас обоих.</div>}
    {open&&<Modal title={editing?'Изменить цель':'Новая общая цель'} description="Вы в любой момент сможете изменить план." onClose={close}><GoalForm initial={editing} onSubmit={save} busy={create.isPending||update.isPending} onClose={close} error={create.isError||update.isError?'Не удалось сохранить цель. Проверьте данные и попробуйте снова.':undefined}/></Modal>}
    {deleteGoal&&<Modal title="Удалить цель?" description={`Цель «${deleteGoal.name}» будет удалена. История взносов останется.`} onClose={()=>setDeleteGoal(null)}>{remove.isError&&<p className="form-error">Не удалось удалить цель. Попробуйте ещё раз.</p>}<div className="confirm-actions"><button className="button button-soft" onClick={()=>setDeleteGoal(null)}>Оставить</button><button className="button button-danger" disabled={remove.isPending} onClick={()=>remove.mutate({id:deleteGoal.id},{onSuccess:()=>{setDeleteGoal(null);void refresh()}})}>Удалить цель</button></div></Modal>}
    {contribute&&<Modal title="Пополнить цель" description={`Взнос в «${contribute.name}» появится в общей истории.`} onClose={()=>setContribute(undefined)}><TransactionForm presetGoal={contribute} goals={q.data??[]} busy={txcreate.isPending} onClose={()=>setContribute(undefined)} error={txcreate.isError?'Не удалось добавить взнос. Попробуйте ещё раз.':undefined} onSubmit={data=>txcreate.mutate({data:data as TransactionInput},{onSuccess:()=>{setContribute(undefined);void refresh()}})}/></Modal>}
  </AppFrame>;
}

function ReportsPage() {
  const [from,setFrom]=useState(currentMonthStart);const [to,setTo]=useState(today);const params={fromDate:from,toDate:to};const q=useGetReport(params,{query:{queryKey:getGetReportQueryKey(params),refetchInterval:30_000}});
  const maxDaily=Math.max(1,...(q.data?.dailyTotals??[]).map(d=>Math.max(d.income,d.expenses,d.savings)));
  return <AppFrame title="Отчёты" subtitle="Финансовая картина за выбранный период">
    <section className="report-filter panel"><div><span className="section-kicker">ПЕРИОД</span><h2>Сравните и замечайте</h2></div><div className="report-date-fields"><label><span className="field-label">Начало</span><input className="field" type="date" value={from} onChange={e=>setFrom(e.target.value)} data-testid="report-from-date"/></label><span className="date-separator">—</span><label><span className="field-label">Конец</span><input className="field" type="date" value={to} onChange={e=>setTo(e.target.value)} data-testid="report-to-date"/></label></div></section>
    {q.isLoading?<Loading label="Подготавливаем отчёт"/>:q.isError?<ErrorState retry={()=>q.refetch()}/>:q.data&&<div className="report-content">
      <div className="report-summary"><div className="report-available"><span>ОСТАЛОСЬ ЗА ПЕРИОД</span><strong>{money(q.data.available)}</strong><small>{dateRu(q.data.fromDate)} — {dateRu(q.data.toDate)}</small></div><StatCard label="Доходы" value={q.data.income} icon={ArrowDownLeft} tone="income-card"/><StatCard label="Расходы" value={q.data.expenses} icon={ArrowUpRight} tone="expense-card"/><StatCard label="Накопления" value={q.data.savings} icon={Target} tone="saving-card"/></div>
      <div className="report-grid"><section className="panel section-panel"><div className="section-title"><div><span className="section-kicker">РИТМ ПЕРИОДА</span><h2>По дням</h2></div><TrendingUp size={17}/></div>
        {q.data.dailyTotals.length?<div className="daily-chart">{q.data.dailyTotals.slice(-14).map((day,index)=><div className="daily-column" key={day.date} title={`${dateRu(day.date)} · расходы ${money(day.expenses)}`}><div className="daily-bars"><i style={{height:`${Math.max(day.income?3:0,day.income/maxDaily*100)}%`}}/><b style={{height:`${Math.max(day.expenses?3:0,day.expenses/maxDaily*100)}%`}}/><em style={{height:`${Math.max(day.savings?3:0,day.savings/maxDaily*100)}%`}}/></div><span>{index%2===0?new Date(day.date+'T12:00:00').getDate():''}</span></div>)}</div>:<EmptyState title="Пока нет данных по дням" body="Операции за выбранный период появятся здесь."/>}
        <div className="chart-legend"><span><i className="legend-income"/> Доходы</span><span><i className="legend-expense"/> Расходы</span><span><i className="legend-saving"/> Накопления</span></div>
      </section><section className="panel section-panel"><div className="section-title"><div><span className="section-kicker">РАСХОДЫ</span><h2>Структура</h2></div><CreditCard size={17}/></div>
        {q.data.expenseByCategory.length?<div className="report-categories">{q.data.expenseByCategory.slice().sort((a,b)=>b.amount-a.amount).map((c,i)=>{const pct=q.data!.expenses?c.amount/q.data!.expenses*100:0;return <div className="report-category" key={c.category}><div><span><i className={`category-dot ${categoryHue[i%categoryHue.length]}`}/>{c.category}</span><b>{money(c.amount)}</b></div><div className="category-track"><span className={categoryHue[i%categoryHue.length]} style={{width:`${pct}%`}}/></div><small>{pct.toLocaleString('ru-RU',{maximumFractionDigits:1})}% расходов</small></div>})}</div>:<p className="muted-note">За этот период расходов нет.</p>}
      </section></div>
      <section className="report-planned"><span className="planned-sun"><CalendarDays size={18}/></span><div><strong>Запланированные расходы</strong><p>На выбранный период</p></div><b>{money(q.data.plannedExpenses)}</b></section>
    </div>}
  </AppFrame>;
}

function SetupPage() {
  const [joining,setJoining]=useState(false);const [name,setName]=useState('');const [displayName,setDisplayName]=useState('');const [inviteCode,setInviteCode]=useState('');const [error,setError]=useState('');
  const create=useCreateHousehold();const join=useJoinHousehold();const refresh=useRefresh();const busy=create.isPending||join.isPending;
  const submit=(e:FormEvent)=>{e.preventDefault();setError('');const done=()=>{void refresh()};if(joining)join.mutate({data:{inviteCode:inviteCode.trim(),displayName:displayName.trim()}},{onSuccess:done,onError:()=>setError('Не удалось присоединиться. Проверьте код и попробуйте ещё раз.')});else create.mutate({data:{name:name.trim(),displayName:displayName.trim()}},{onSuccess:done,onError:()=>setError('Не удалось создать пространство. Попробуйте ещё раз.')})};
  return <div className="setup-page"><div className="setup-top"><Brand /><button className="button button-plain" onClick={()=>setJoining(!joining)}>{joining?'Создать новое':'Есть код приглашения?'} <ArrowRight size={15}/></button></div>
    <div className="setup-layout"><div className="setup-copy"><span className="eyebrow"><span className="eyebrow-dot"/> Только для двоих</span><h1>{joining?<>Войдите в<br/><em>ваш общий дом.</em></>:<>Начните с<br/><em>общего пространства.</em></>}</h1><p>{joining?'Введите код приглашения, который вам отправил близкий человек.':'Создайте бюджет, а потом пригласите второго участника по коду.'}</p><div className="setup-promise"><ShieldCheck size={18}/><span>Приватно и только для вас двоих</span></div></div>
      <form className="setup-form panel" onSubmit={submit}><span className="section-kicker">{joining?'ПРИСОЕДИНИТЬСЯ':'СОЗДАТЬ БЮДЖЕТ'}</span><h2>{joining?'Код уже у вас?':'Как вас называть?'}</h2>
        <label><span className="field-label">Ваше имя</span><input className="field" value={displayName} onChange={e=>setDisplayName(e.target.value)} maxLength={60} placeholder="Имя для общего бюджета" required data-testid="input-display-name"/></label>
        {joining?<label><span className="field-label">Код приглашения</span><input className="field invite-field" value={inviteCode} onChange={e=>setInviteCode(e.target.value.toUpperCase())} minLength={6} maxLength={32} placeholder="Например, A7K9Q2" required data-testid="input-invite-code"/></label>:<label><span className="field-label">Название вашего бюджета</span><input className="field" value={name} onChange={e=>setName(e.target.value)} maxLength={80} placeholder="Например, Дом Лены и Ильи" required data-testid="input-household-name"/></label>}
        {error&&<p className="form-error" role="alert">{error}</p>}<button className="button button-primary setup-submit" disabled={busy}>{busy?'Создаём…':joining?'Присоединиться':'Создать пространство'} <ArrowRight size={16}/></button><p className="setup-footnote">Можно начать сейчас и позвать близкого чуть позже.</p>
      </form>
    </div><div className="setup-bottom"><span>вдвоём — общий бюджет</span><span>Ваши финансы остаются вашими</span></div>
  </div>;
}

function ProtectedRoutes() {
  const { isLoaded, isSignedIn }=useAuth();const household=useGetHousehold({query:{enabled:!!isSignedIn,queryKey:getGetHouseholdQueryKey(),refetchInterval:30_000}});
  if(!isLoaded)return <div className="auth-loading"><Brand/><div className="loading-panel"><div className="skeleton-line short"/></div></div>;
  if(!isSignedIn)return <Redirect to="/"/>;
  if(household.isLoading)return <div className="auth-loading"><Brand/><Loading label="Открываем ваш общий бюджет"/></div>;
  if(household.isError)return <div className="auth-loading"><Brand/><ErrorState retry={()=>household.refetch()} label="Не удалось открыть общий бюджет"/></div>;
  if(!household.data?.household)return <SetupPage/>;
  return <Switch><Route path="/dashboard" component={Dashboard}/><Route path="/transactions" component={TransactionsPage}/><Route path="/savings" component={SavingsPage}/><Route path="/reports" component={ReportsPage}/><Route path="/setup"><Redirect to="/dashboard"/></Route><Route><Redirect to="/dashboard"/></Route></Switch>;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: {
    colorPrimary:'#416f60', colorForeground:'#293b34', colorMutedForeground:'#78857e', colorDanger:'#b65f56',
    colorBackground:'#fbfaf5', colorInput:'#fffefa', colorInputForeground:'#293b34', colorNeutral:'#deddd4',
    fontFamily:'DM Sans, sans-serif', borderRadius:'0.8rem',
  },
  elements: {
    rootBox:'w-full flex justify-center', cardBox:'bg-[#fbfaf5] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-none',
    card:'!shadow-none !border-0 !bg-transparent !rounded-none', footer:'!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle:'text-[#293b34] font-semibold', headerSubtitle:'text-[#78857e]', socialButtonsBlockButtonText:'text-[#293b34] font-medium',
    formFieldLabel:'text-[#52635b] font-medium', footerActionLink:'text-[#416f60] font-semibold', footerActionText:'text-[#78857e]',
    dividerText:'text-[#78857e]', identityPreviewEditButton:'text-[#416f60]', formFieldSuccessText:'text-[#416f60]', alertText:'text-[#293b34]',
    logoBox:'rounded-lg', logoImage:'object-contain', socialButtonsBlockButton:'border border-[#deddd4] rounded-xl bg-[#fffefa]',
    formButtonPrimary:'bg-[#416f60] text-white rounded-xl shadow-none', formFieldInput:'bg-[#fffefa] border-[#deddd4] text-[#293b34] rounded-xl',
    footerAction:'bg-transparent', dividerLine:'bg-[#deddd4]', alert:'rounded-xl', otpCodeFieldInput:'bg-[#fffefa] border-[#deddd4] rounded-xl',
    formFieldRow:'gap-2', main:'gap-4',
  },
};
function Routes() {
  const [,setLocation]=useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance}
    signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={{signIn:{start:{title:'С возвращением',subtitle:'Войдите в общий бюджет'}},signUp:{start:{title:'Создайте аккаунт',subtitle:'Начните вести бюджет вместе'}}}}
     routerPush={(to: string)=>setLocation(stripBase(to))} routerReplace={(to: string)=>setLocation(stripBase(to),{replace:true})}>
    <ClerkCacheInvalidator/>
    <Switch><Route path="/" component={AuthHome}/><Route path="/sign-in/*?" component={SignInPage}/><Route path="/sign-up/*?" component={SignUpPage}/><Route component={ProtectedRoutes}/></Switch>
  </ClerkProvider>;
}
function App() {
  if(!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in environment.');
  return <QueryClientProvider client={queryClient}><WouterRouter base={basePath}><Routes/></WouterRouter></QueryClientProvider>;
}
export default App;
