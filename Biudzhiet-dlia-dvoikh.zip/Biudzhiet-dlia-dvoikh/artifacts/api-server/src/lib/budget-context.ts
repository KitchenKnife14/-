import { eq } from "drizzle-orm";
import {
  db,
  householdMembersTable,
  householdsTable,
} from "@workspace/db";

export async function getHouseholdMember(clerkUserId: string) {
  const [member] = await db
    .select()
    .from(householdMembersTable)
    .where(eq(householdMembersTable.clerkUserId, clerkUserId))
    .limit(1);

  return member ?? null;
}

export async function getHouseholdOverview(clerkUserId: string) {
  const member = await getHouseholdMember(clerkUserId);
  if (!member) {
    return { household: null, members: [] };
  }

  const [household] = await db
    .select()
    .from(householdsTable)
    .where(eq(householdsTable.id, member.householdId))
    .limit(1);
  const members = await db
    .select({
      id: householdMembersTable.id,
      displayName: householdMembersTable.displayName,
      createdAt: householdMembersTable.createdAt,
    })
    .from(householdMembersTable)
    .where(eq(householdMembersTable.householdId, member.householdId))
    .orderBy(householdMembersTable.createdAt);

  if (!household) {
    return { household: null, members: [] };
  }

  return {
    household: {
      ...household,
      memberCount: members.length,
    },
    members,
  };
}
