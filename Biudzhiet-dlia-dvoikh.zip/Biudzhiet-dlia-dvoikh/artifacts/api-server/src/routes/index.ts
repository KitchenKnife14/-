import { Router, type IRouter } from "express";
import healthRouter from "./health";
import householdRouter from "./household";
import financeRouter from "./finance";

const router: IRouter = Router();

router.use(healthRouter);
router.use(householdRouter);
router.use(financeRouter);

export default router;
