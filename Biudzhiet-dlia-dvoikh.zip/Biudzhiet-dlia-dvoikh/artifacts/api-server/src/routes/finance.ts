import {
  and,
  desc,
  eq,
  gte,
  isNotNull,
  lte,
  sql,
} from "drizzle-orm";
import { Router, type IRouter, type Response } from "express";
import {
  CreateGoalBody,
  CreateGoalResponse,
  CreateTransactionBody,
  CreateTransactionResponse,
  DeleteGoalParams,
  DeleteTransactionParams,
  GetDashboardResponse,
  GetReportQueryParams,
  GetReportResponse,
  ListGoalsResponse,
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  UpdateGoalBody,
  UpdateGoalParams,
  UpdateGoalResponse,
  UpdateTransactionBody,
  UpdateTransactionParams,
  UpdateTransactionResponse,
} from "@workspace/api-zod";
import {
  budgetTransactionsTable,
  db,
  householdMembersTable,
  savingsGoalsTable,
} from "@workspace/db";
import { getHouseholdMember } from "../lib/budget-context";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();
router.use(requireAuth);

type TransactionType = "income" | "expense" | "saving";
type TransactionStatus = "recorded" | "planned";
type TransactionView = {
  id: number;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  transactionDate: string;
  status: TransactionStatus;
  goalId: number | null;
  goalName: string | null;
  authorName: string;
  createdAt: string;
};

function clerkUserId(res: Response): string {
  return res.locals.clerkUserId as string;
}

function formatCalendarDate(value: string | Date): string {
  return typeof value === "string"
    ? value
    : value.toISOString().slice(0, 10);
}

async function getRequiredMember(
  res: Response,
): Promise<
  | { member: NonNullable<Awaited<ReturnType<typeof getHouseholdMember>>> }
  | { error: string }
> {
  const member = await getHouseholdMember(clerkUserId(res));
  return member
    ? { member }
    : { error: "Create or join a household before managing its budget." };
}

function transactionView(
  row: {
    id: number;
    type: string;
    amount: string;
    category: string;
    description: string;
    transactionDate: string;
    status: string;
    goalId: number | null;
    goalName: string | null;
    authorName: string;
    createdAt: Date;
  },
): TransactionView {
  return {
    id: row.id,
    type: row.type as TransactionType,
    amount: Number(row.amount),
    category: row.category,
    description: row.description,
    transactionDate: row.transactionDate,
    status: row.status as TransactionStatus,
    goalId: row.goalId,
    goalName: row.goalName,
    authorName: row.authorName,
    createdAt: row.createdAt.toISOString(),
  };
}

async function selectTransactionRows(
  householdId: number,
  filters: {
    fromDate?: string;
    toDate?: string;
    type?: TransactionType;
    status?: TransactionStatus;
    id?: number;
  } = {},
  limit?: number,
) {
  const conditions = [eq(budgetTransactionsTable.householdId, householdId)];
  if (filters.fromDate) {
    conditions.push(gte(budgetTransactionsTable.transactionDate, filters.fromDate));
  }
  if (filters.toDate) {
    conditions.push(lte(budgetTransactionsTable.transactionDate, filters.toDate));
  }
  if (filters.type) {
    conditions.push(eq(budgetTransactionsTable.type, filters.type));
  }
  if (filters.status) {
    conditions.push(eq(budgetTransactionsTable.status, filters.status));
  }
  if (filters.id) {
    conditions.push(eq(budgetTransactionsTable.id, filters.id));
  }

  const query = db
    .select({
      id: budgetTransactionsTable.id,
      type: budgetTransactionsTable.type,
      amount: budgetTransactionsTable.amount,
      category: budgetTransactionsTable.category,
      description: budgetTransactionsTable.description,
      transactionDate: budgetTransactionsTable.transactionDate,
      status: budgetTransactionsTable.status,
      goalId: budgetTransactionsTable.goalId,
      goalName: savingsGoalsTable.name,
      authorName: householdMembersTable.displayName,
      createdAt: budgetTransactionsTable.createdAt,
    })
    .from(budgetTransactionsTable)
    .innerJoin(
      householdMembersTable,
      eq(budgetTransactionsTable.authorMemberId, householdMembersTable.id),
    )
    .leftJoin(
      savingsGoalsTable,
      eq(budgetTransactionsTable.goalId, savingsGoalsTable.id),
    )
    .where(and(...conditions))
    .orderBy(
      desc(budgetTransactionsTable.transactionDate),
      desc(budgetTransactionsTable.createdAt),
    );

  const rows = limit ? await query.limit(limit) : await query;
  return rows.map(transactionView);
}

async function findOwnedTransaction(id: number, householdId: number) {
  const [transaction] = await db
    .select()
    .from(budgetTransactionsTable)
    .where(
      and(
        eq(budgetTransactionsTable.id, id),
        eq(budgetTransactionsTable.householdId, householdId),
      ),
    )
    .limit(1);

  return transaction ?? null;
}

async function goalViews(householdId: number) {
  const goals = await db
    .select()
    .from(savingsGoalsTable)
    .where(eq(savingsGoalsTable.householdId, householdId))
    .orderBy(savingsGoalsTable.createdAt);
  const balances = await db
    .select({
      goalId: budgetTransactionsTable.goalId,
      currentAmount: sql<string>`coalesce(sum(${budgetTransactionsTable.amount}), 0)`,
    })
    .from(budgetTransactionsTable)
    .where(
      and(
        eq(budgetTransactionsTable.householdId, householdId),
        eq(budgetTransactionsTable.type, "saving"),
        eq(budgetTransactionsTable.status, "recorded"),
        isNotNull(budgetTransactionsTable.goalId),
      ),
    )
    .groupBy(budgetTransactionsTable.goalId);
  const amountByGoal = new Map(
    balances.map((balance) => [
      balance.goalId as number,
      Number(balance.currentAmount),
    ]),
  );

  return goals.map((goal) => {
    const targetAmount = Number(goal.targetAmount);
    const currentAmount = amountByGoal.get(goal.id) ?? 0;
    return {
      id: goal.id,
      name: goal.name,
      targetAmount,
      currentAmount,
      deadline: goal.deadline,
      progressPercent:
        targetAmount > 0
          ? Math.min(100, Math.round((currentAmount / targetAmount) * 100))
          : 0,
      createdAt: goal.createdAt.toISOString(),
    };
  });
}

function summarize(
  transactions: TransactionView[],
  fromDate: string,
  toDate: string,
) {
  let income = 0;
  let expenses = 0;
  let savings = 0;
  let plannedExpenses = 0;
  const categoryTotals = new Map<string, number>();
  const dailyTotals = new Map<
    string,
    { income: number; expenses: number; savings: number }
  >();

  for (const transaction of transactions) {
    if (transaction.type === "expense" && transaction.status === "planned") {
      plannedExpenses += transaction.amount;
      continue;
    }
    if (transaction.status !== "recorded") {
      continue;
    }

    let day = dailyTotals.get(transaction.transactionDate);
    if (!day) {
      day = { income: 0, expenses: 0, savings: 0 };
      dailyTotals.set(transaction.transactionDate, day);
    }

    if (transaction.type === "income") {
      income += transaction.amount;
      day.income += transaction.amount;
    } else if (transaction.type === "expense") {
      expenses += transaction.amount;
      day.expenses += transaction.amount;
      categoryTotals.set(
        transaction.category,
        (categoryTotals.get(transaction.category) ?? 0) + transaction.amount,
      );
    } else {
      savings += transaction.amount;
      day.savings += transaction.amount;
    }
  }

  return {
    fromDate,
    toDate,
    income,
    expenses,
    savings,
    plannedExpenses,
    available: income - expenses - savings - plannedExpenses,
    expenseByCategory: [...categoryTotals.entries()]
      .map(([category, amount]) => ({ category, amount }))
      .sort((left, right) => right.amount - left.amount),
    dailyTotals: [...dailyTotals.entries()]
      .map(([date, totals]) => ({ date, ...totals }))
      .sort((left, right) => left.date.localeCompare(right.date)),
  };
}

function moscowMonthRange(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Moscow",
    year: "numeric",
    month: "2-digit",
  }).formatToParts(date);
  const year = parts.find((part) => part.type === "year")?.value ?? "2026";
  const month = parts.find((part) => part.type === "month")?.value ?? "01";
  const lastDay = new Date(
    Date.UTC(Number(year), Number(month), 0),
  ).getUTCDate();

  return {
    month: `${year}-${month}`,
    fromDate: `${year}-${month}-01`,
    toDate: `${year}-${month}-${String(lastDay).padStart(2, "0")}`,
  };
}

router.get("/transactions", async (req, res): Promise<void> => {
  const query = ListTransactionsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const transactions = await selectTransactionRows(context.member.householdId, {
    fromDate:
      query.data.fromDate === undefined
        ? undefined
        : formatCalendarDate(query.data.fromDate),
    toDate:
      query.data.toDate === undefined
        ? undefined
        : formatCalendarDate(query.data.toDate),
    type: query.data.type,
    status: query.data.status,
  });
  res.json(ListTransactionsResponse.parse(transactions));
});

router.post("/transactions", async (req, res): Promise<void> => {
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const input = parsed.data;
  if (input.type === "saving" && input.goalId === null) {
    res.status(400).json({ error: "Choose a savings goal for this contribution." });
    return;
  }
  if (input.type !== "saving" && input.goalId !== null) {
    res.status(400).json({ error: "Only savings contributions can reference a goal." });
    return;
  }
  if (input.goalId !== null) {
    const [goal] = await db
      .select({ id: savingsGoalsTable.id })
      .from(savingsGoalsTable)
      .where(
        and(
          eq(savingsGoalsTable.id, input.goalId),
          eq(savingsGoalsTable.householdId, context.member.householdId),
        ),
      )
      .limit(1);
    if (!goal) {
      res.status(400).json({ error: "The selected savings goal was not found." });
      return;
    }
  }

  const [created] = await db
    .insert(budgetTransactionsTable)
    .values({
      householdId: context.member.householdId,
      authorMemberId: context.member.id,
      type: input.type,
      amount: String(input.amount),
      category: input.category,
      description: input.description,
      transactionDate: formatCalendarDate(input.transactionDate),
      status: input.status,
      goalId: input.goalId,
    })
    .returning({ id: budgetTransactionsTable.id });

  const [transaction] = await selectTransactionRows(
    context.member.householdId,
    { id: created.id },
  );
  res.status(201).json(CreateTransactionResponse.parse(transaction));
});

router.patch("/transactions/:id", async (req, res): Promise<void> => {
  const params = UpdateTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (Object.keys(parsed.data).length === 0) {
    res.status(400).json({ error: "Add at least one field to update." });
    return;
  }

  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }
  const current = await findOwnedTransaction(
    params.data.id,
    context.member.householdId,
  );
  if (!current) {
    res.status(404).json({ error: "Transaction not found." });
    return;
  }

  const input = parsed.data;
  const nextType = input.type ?? (current.type as TransactionType);
  let nextGoalId =
    input.goalId !== undefined ? input.goalId : current.goalId;
  if (nextType === "saving" && nextGoalId === null) {
    res.status(400).json({ error: "Choose a savings goal for this contribution." });
    return;
  }
  if (nextType !== "saving") {
    if (input.goalId !== undefined && input.goalId !== null) {
      res.status(400).json({ error: "Only savings contributions can reference a goal." });
      return;
    }
    nextGoalId = null;
  }
  if (nextGoalId !== null) {
    const [goal] = await db
      .select({ id: savingsGoalsTable.id })
      .from(savingsGoalsTable)
      .where(
        and(
          eq(savingsGoalsTable.id, nextGoalId),
          eq(savingsGoalsTable.householdId, context.member.householdId),
        ),
      )
      .limit(1);
    if (!goal) {
      res.status(400).json({ error: "The selected savings goal was not found." });
      return;
    }
  }

  await db
    .update(budgetTransactionsTable)
    .set({
      ...input,
      goalId: nextGoalId,
      transactionDate:
        input.transactionDate === undefined
          ? undefined
          : formatCalendarDate(input.transactionDate),
      amount: input.amount === undefined ? undefined : String(input.amount),
    })
    .where(
      and(
        eq(budgetTransactionsTable.id, params.data.id),
        eq(budgetTransactionsTable.householdId, context.member.householdId),
      ),
    );

  const [transaction] = await selectTransactionRows(
    context.member.householdId,
    { id: params.data.id },
  );
  res.json(UpdateTransactionResponse.parse(transaction));
});

router.delete("/transactions/:id", async (req, res): Promise<void> => {
  const params = DeleteTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const [deleted] = await db
    .delete(budgetTransactionsTable)
    .where(
      and(
        eq(budgetTransactionsTable.id, params.data.id),
        eq(budgetTransactionsTable.householdId, context.member.householdId),
      ),
    )
    .returning({ id: budgetTransactionsTable.id });
  if (!deleted) {
    res.status(404).json({ error: "Transaction not found." });
    return;
  }

  res.sendStatus(204);
});

router.get("/goals", async (_req, res): Promise<void> => {
  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }
  res.json(ListGoalsResponse.parse(await goalViews(context.member.householdId)));
});

router.post("/goals", async (req, res): Promise<void> => {
  const parsed = CreateGoalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const [goal] = await db
    .insert(savingsGoalsTable)
    .values({
      householdId: context.member.householdId,
      name: parsed.data.name,
      targetAmount: String(parsed.data.targetAmount),
      deadline:
        parsed.data.deadline === null
          ? null
          : formatCalendarDate(parsed.data.deadline),
    })
    .returning({ id: savingsGoalsTable.id });
  const created = (await goalViews(context.member.householdId)).find(
    (item) => item.id === goal.id,
  );
  res.status(201).json(CreateGoalResponse.parse(created));
});

router.patch("/goals/:id", async (req, res): Promise<void> => {
  const params = UpdateGoalParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateGoalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (Object.keys(parsed.data).length === 0) {
    res.status(400).json({ error: "Add at least one field to update." });
    return;
  }

  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }
  const [updated] = await db
    .update(savingsGoalsTable)
    .set({
      ...parsed.data,
      targetAmount:
        parsed.data.targetAmount === undefined
          ? undefined
          : String(parsed.data.targetAmount),
      deadline:
        parsed.data.deadline === undefined || parsed.data.deadline === null
          ? parsed.data.deadline
          : formatCalendarDate(parsed.data.deadline),
    })
    .where(
      and(
        eq(savingsGoalsTable.id, params.data.id),
        eq(savingsGoalsTable.householdId, context.member.householdId),
      ),
    )
    .returning({ id: savingsGoalsTable.id });
  if (!updated) {
    res.status(404).json({ error: "Savings goal not found." });
    return;
  }

  const goal = (await goalViews(context.member.householdId)).find(
    (item) => item.id === updated.id,
  );
  res.json(UpdateGoalResponse.parse(goal));
});

router.delete("/goals/:id", async (req, res): Promise<void> => {
  const params = DeleteGoalParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const [deleted] = await db
    .delete(savingsGoalsTable)
    .where(
      and(
        eq(savingsGoalsTable.id, params.data.id),
        eq(savingsGoalsTable.householdId, context.member.householdId),
      ),
    )
    .returning({ id: savingsGoalsTable.id });
  if (!deleted) {
    res.status(404).json({ error: "Savings goal not found." });
    return;
  }

  res.sendStatus(204);
});

router.get("/dashboard", async (_req, res): Promise<void> => {
  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const range = moscowMonthRange();
  const monthTransactions = await selectTransactionRows(
    context.member.householdId,
    { fromDate: range.fromDate, toDate: range.toDate },
  );
  const summary = summarize(
    monthTransactions,
    range.fromDate,
    range.toDate,
  );
  const recentTransactions = await selectTransactionRows(
    context.member.householdId,
    {},
    8,
  );

  res.json(
    GetDashboardResponse.parse({
      month: range.month,
      income: summary.income,
      expenses: summary.expenses,
      savings: summary.savings,
      plannedExpenses: summary.plannedExpenses,
      available: summary.available,
      expenseByCategory: summary.expenseByCategory,
      recentTransactions,
    }),
  );
});

router.get("/reports", async (req, res): Promise<void> => {
  const query = GetReportQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const fromDate = formatCalendarDate(query.data.fromDate);
  const toDate = formatCalendarDate(query.data.toDate);
  if (fromDate > toDate) {
    res.status(400).json({ error: "The start date must not follow the end date." });
    return;
  }

  const context = await getRequiredMember(res);
  if ("error" in context) {
    res.status(409).json({ error: context.error });
    return;
  }

  const transactions = await selectTransactionRows(context.member.householdId, {
    fromDate,
    toDate,
  });
  res.json(
    GetReportResponse.parse(
      summarize(transactions, fromDate, toDate),
    ),
  );
});

export default router;
