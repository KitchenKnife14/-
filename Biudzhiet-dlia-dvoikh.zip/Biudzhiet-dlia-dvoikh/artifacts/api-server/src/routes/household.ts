import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { Router, type IRouter, type Response } from "express";
import {
  CreateHouseholdBody,
  CreateHouseholdResponse,
  GetHouseholdResponse,
  JoinHouseholdBody,
  JoinHouseholdResponse,
} from "@workspace/api-zod";
import {
  db,
  householdMembersTable,
  householdsTable,
} from "@workspace/db";
import { getHouseholdOverview, getHouseholdMember } from "../lib/budget-context";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();
router.use(requireAuth);

function clerkUserId(res: Response): string {
  return res.locals.clerkUserId as string;
}

router.get("/household", async (_req, res): Promise<void> => {
  const overview = await getHouseholdOverview(clerkUserId(res));
  res.json(GetHouseholdResponse.parse(overview));
});

router.post("/household", async (req, res): Promise<void> => {
  const parsed = CreateHouseholdBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = clerkUserId(res);
  if (await getHouseholdMember(userId)) {
    res.status(409).json({ error: "This account already belongs to a household." });
    return;
  }

  await db.transaction(async (tx) => {
    const [household] = await tx
      .insert(householdsTable)
      .values({
        name: parsed.data.name,
        inviteCode: randomBytes(6).toString("hex").toUpperCase(),
      })
      .returning();

    const [member] = await tx
      .insert(householdMembersTable)
      .values({
        householdId: household.id,
        clerkUserId: userId,
        displayName: parsed.data.displayName,
      })
      .returning();

    return { household, member };
  });

  const overview = await getHouseholdOverview(userId);
  res.status(201).json(CreateHouseholdResponse.parse(overview));
});

router.post("/household/join", async (req, res): Promise<void> => {
  const parsed = JoinHouseholdBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = clerkUserId(res);
  if (await getHouseholdMember(userId)) {
    res.status(409).json({ error: "This account already belongs to a household." });
    return;
  }

  const inviteCode = parsed.data.inviteCode.trim().toUpperCase();
  const result = await db.transaction(async (tx) => {
    const [household] = await tx
      .select()
      .from(householdsTable)
      .where(eq(householdsTable.inviteCode, inviteCode))
      .for("update")
      .limit(1);

    if (!household) {
      return { error: "Invite code is not valid." };
    }

    const members = await tx
      .select({ id: householdMembersTable.id })
      .from(householdMembersTable)
      .where(eq(householdMembersTable.householdId, household.id));

    if (members.length >= 2) {
      return { error: "This household already has two members." };
    }

    const [member] = await tx
      .insert(householdMembersTable)
      .values({
        householdId: household.id,
        clerkUserId: userId,
        displayName: parsed.data.displayName,
      })
      .returning();

    return { household, member };
  });

  if ("error" in result) {
    res.status(403).json({ error: result.error });
    return;
  }

  const overview = await getHouseholdOverview(userId);
  res.json(JoinHouseholdResponse.parse(overview));
});

export default router;
