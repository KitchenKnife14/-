---
name: Frontend SDK alignment
description: Version-sensitive Clerk API usage and React Query code generation in this workspace.
---

When following Clerk setup guidance, verify the installed package exports and peer requirements before copying UI imports. The managed setup reference may show exports that are absent from the installed `@clerk/react` version; in the current web stack, signed-in state is available through `useAuth`, and the host-based publishable key helper is available from `@clerk/shared/keys`.

Keep Orval's React Query override aligned with the TanStack Query version used by the web artifact. If Orval cannot infer the version from the API-spec package, it can generate v4 hook option types for a v5 client.

**Why:** The reference snippet and installed Clerk SDK did not match, and Orval initially generated query options for the wrong major version, blocking the app typecheck.

**How to apply:** Before making auth or API-client changes, check the package actually installed in the artifact and its exported types. Keep the Orval query version synchronized with the web artifact's TanStack Query version.
