import {
  date,
  index,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const householdsTable = pgTable(
  "budget_households",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    inviteCode: text("invite_code").notNull().unique(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
);

export const householdMembersTable = pgTable(
  "budget_household_members",
  {
    id: serial("id").primaryKey(),
    householdId: integer("household_id")
      .notNull()
      .references(() => householdsTable.id, { onDelete: "cascade" }),
    clerkUserId: text("clerk_user_id").notNull(),
    displayName: text("display_name").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("budget_members_clerk_user_id_idx").on(table.clerkUserId),
    index("budget_members_household_id_idx").on(table.householdId),
  ],
);

export const savingsGoalsTable = pgTable(
  "budget_savings_goals",
  {
    id: serial("id").primaryKey(),
    householdId: integer("household_id")
      .notNull()
      .references(() => householdsTable.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    targetAmount: numeric("target_amount", {
      precision: 14,
      scale: 2,
    }).notNull(),
    deadline: date("deadline", { mode: "string" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("budget_goals_household_id_idx").on(table.householdId),
  ],
);

export const budgetTransactionsTable = pgTable(
  "budget_transactions",
  {
    id: serial("id").primaryKey(),
    householdId: integer("household_id")
      .notNull()
      .references(() => householdsTable.id, { onDelete: "cascade" }),
    authorMemberId: integer("author_member_id")
      .notNull()
      .references(() => householdMembersTable.id, { onDelete: "restrict" }),
    type: text("type").notNull(),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    category: text("category").notNull(),
    description: text("description").notNull(),
    transactionDate: date("transaction_date", { mode: "string" }).notNull(),
    status: text("status").notNull(),
    goalId: integer("goal_id").references(() => savingsGoalsTable.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("budget_transactions_household_date_idx").on(
      table.householdId,
      table.transactionDate,
    ),
    index("budget_transactions_goal_id_idx").on(table.goalId),
  ],
);

export type Household = typeof householdsTable.$inferSelect;
export type HouseholdMember = typeof householdMembersTable.$inferSelect;
export type SavingsGoal = typeof savingsGoalsTable.$inferSelect;
export type BudgetTransaction = typeof budgetTransactionsTable.$inferSelect;
